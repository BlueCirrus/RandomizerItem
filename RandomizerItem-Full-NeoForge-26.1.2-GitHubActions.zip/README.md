# RandomizerItem

NeoForge 26.1.2 mod project.

Features planned:
- /randomizer on
- /randomizer off
- Random item drops from block breaking
- Vanilla + modded item registry support
- Equal item chance

Build:
./gradlew build
