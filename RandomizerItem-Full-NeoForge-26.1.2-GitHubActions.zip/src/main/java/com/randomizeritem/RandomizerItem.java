package com.randomizeritem;

import net.neoforged.fml.common.Mod;

@Mod(RandomizerItem.MOD_ID)
public class RandomizerItem {
    public static final String MOD_ID = "randomizeritem";
    public static boolean ENABLED = false;

    public RandomizerItem() {
        // Mod initialized
    }
}
