package com.randomizeritem;

public class RandomizerCommand {
    // Command registration placeholder for NeoForge 26.1.2 mappings.
}
